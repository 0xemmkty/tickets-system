import { ticketsApi } from './api';

interface Ticket {
  id: number;
  title: string;
  description: string;
  price: number;
  category: 'concert' | 'sports' | 'movie';
  venue: string;
  date: string;
  totalSeats: number;
  availableSeats: number;
  status: 'draft' | 'published' | 'soldout';
}

export const ticketsService = {
  create: (ticketData: Omit<Ticket, 'id' | 'availableSeats' | 'status'>) => 
    ticketsApi.post<Ticket>('/tickets', ticketData),
  
  update: (id: number, ticketData: Partial<Ticket>) => 
    ticketsApi.put<Ticket>(`/tickets/${id}`, ticketData),
  
  getAll: () => 
    ticketsApi.get<Ticket[]>('/tickets'),
  
  getOne: (id: number) => 
    ticketsApi.get<Ticket>(`/tickets/${id}`)
}; 