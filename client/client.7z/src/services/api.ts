import axios from 'axios';

// 创建两个不同的 API 实例
const authApi = axios.create({
  baseURL: 'http://localhost:3000/api',
  headers: {
    'Content-Type': 'application/json'
  }
});

const ticketsApi = axios.create({
  baseURL: 'http://localhost:3002/api',
  headers: {
    'Content-Type': 'application/json'
  }
});

// 为两个实例添加认证拦截器
const addAuthInterceptor = (api: any) => {
  api.interceptors.request.use((config: any) => {
    const token = localStorage.getItem('token');
    if (token) {
      // 打印调试信息
      console.log('Adding token to request:', token);
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  });
};

addAuthInterceptor(authApi);
addAuthInterceptor(ticketsApi);

export { authApi, ticketsApi }; 