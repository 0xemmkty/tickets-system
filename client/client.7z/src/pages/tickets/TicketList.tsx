import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Box,
  Button,
  Card,
  CardContent,
  Grid,
  Typography,
  Chip
} from '@mui/material';
import { ticketsService } from '../../services/tickets';

interface Ticket {
  id: number;
  title: string;
  price: number;
  category: string;
  venue: string;
  date: string;
  availableSeats: number;
  status: string;
}

const TicketList = () => {
  const [tickets, setTickets] = useState<Ticket[]>([]);

  useEffect(() => {
    const loadTickets = async () => {
      const response = await ticketsService.getAll();
      setTickets(response.data);
    };
    loadTickets();
  }, []);

  return (
    <Box sx={{ mt: 4 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
        <Typography variant="h4">Tickets</Typography>
        <Button
          component={Link}
          to="/tickets/new"
          variant="contained"
          color="primary"
        >
          Create Ticket
        </Button>
      </Box>

      <Grid container spacing={3}>
        {tickets.map((ticket) => (
          <Grid item xs={12} sm={6} md={4} key={ticket.id}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  {ticket.title}
                </Typography>
                <Typography color="textSecondary">
                  {new Date(ticket.date).toLocaleDateString()}
                </Typography>
                <Typography variant="body2">
                  Venue: {ticket.venue}
                </Typography>
                <Typography variant="h6" sx={{ mt: 2 }}>
                  ${ticket.price}
                </Typography>
                <Box sx={{ mt: 2, display: 'flex', justifyContent: 'space-between' }}>
                  <Chip
                    label={ticket.category}
                    color="primary"
                    size="small"
                  />
                  <Chip
                    label={`${ticket.availableSeats} seats`}
                    color={ticket.availableSeats > 0 ? "success" : "error"}
                    size="small"
                  />
                </Box>
                <Button
                  component={Link}
                  to={`/tickets/${ticket.id}`}
                  variant="outlined"
                  fullWidth
                  sx={{ mt: 2 }}
                >
                  View Details
                </Button>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default TicketList; 