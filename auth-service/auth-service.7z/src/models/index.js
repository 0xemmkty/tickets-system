const { Sequelize } = require('sequelize');
const config = require('../config');

const sequelize = new Sequelize({
  ...config.database,
  logging: false
});

// 初始化模型
const User = require('./user')(sequelize);

const models = {
  User
};

// 测试连接
const testConnection = async () => {
  try {
    await sequelize.authenticate();
    console.log('Database connection has been established successfully.');
  } catch (error) {
    console.error('Unable to connect to the database:', error);
    process.exit(1);
  }
};

module.exports = {
  sequelize,
  ...models,
  testConnection
}; 