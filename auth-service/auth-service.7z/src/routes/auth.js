const express = require('express');
const jwt = require('jsonwebtoken');
const { body } = require('express-validator');
const { User } = require('../models');
const { validateRequest } = require('../middlewares/validate-request');
const config = require('../config');

const router = express.Router();

router.post('/signup',
  [
    body('email').isEmail().withMessage('Email must be valid'),
    body('password')
      .trim()
      .isLength({ min: 4, max: 20 })
      .withMessage('Password must be between 4 and 20 characters')
  ],
  validateRequest,
  async (req, res) => {
    const { email, password } = req.body;

    const existingUser = await User.findOne({ where: { email } });
    if (existingUser) {
      return res.status(400).json({
        errors: [{ message: 'Email in use' }]
      });
    }

    const user = await User.create({
      email,
      password,
      role: 'user'
    });

    // 使用配置中的 JWT 密钥
    const token = jwt.sign(
      { id: user.id, email: user.email },
      config.jwtKey
    );

    res.status(201).json({
      user: {
        id: user.id,
        email: user.email,
        role: user.role
      },
      token
    });
  }
);

router.post('/signin',
  [
    body('email').isEmail().withMessage('Email must be valid'),
    body('password').trim().notEmpty().withMessage('You must supply a password')
  ],
  validateRequest,
  async (req, res) => {
    const { email, password } = req.body;

    const user = await User.findOne({ where: { email } });
    if (!user) {
      return res.status(400).json({
        errors: [{ message: 'Invalid credentials' }]
      });
    }

    const passwordMatch = await user.comparePassword(password);
    if (!passwordMatch) {
      return res.status(400).json({
        errors: [{ message: 'Invalid credentials' }]
      });
    }

    const token = jwt.sign(
      { id: user.id, email: user.email },
      config.jwtKey
    );

    res.json({
      user: {
        id: user.id,
        email: user.email,
        role: user.role
      },
      token
    });
  }
);

module.exports = router; 