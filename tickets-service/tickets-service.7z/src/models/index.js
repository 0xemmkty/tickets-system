const { Sequelize } = require('sequelize');
const config = require('../config');

const sequelize = new Sequelize({
  ...config.database,
  logging: false
});

// 初始化模型
const Ticket = require('./ticket')(sequelize);

const models = {
  Ticket
};

module.exports = {
  sequelize,
  ...models
}; 