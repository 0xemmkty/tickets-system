const config = {
  database: {
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 5432,
    username: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || 'postgres123',
    database: process.env.DB_NAME || 'ticket_tickets',
    dialect: 'postgres'
  },
  port: process.env.PORT || 3002,
  jwtKey: 'shared_jwt_secret_key_123'
};

module.exports = config; 