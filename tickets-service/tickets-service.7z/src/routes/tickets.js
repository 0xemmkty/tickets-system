const express = require('express');
const { body } = require('express-validator');
const { validateRequest } = require('../middlewares/validate-request');
const { requireAuth } = require('../middlewares/require-auth');
const { Ticket } = require('../models');

const router = express.Router();

// 创建票务 - 需要认证
router.post('/',
  requireAuth,
  [
    body('title').trim().notEmpty().withMessage('Title is required'),
    body('description').trim().notEmpty().withMessage('Description is required'),
    body('price')
      .isFloat({ gt: 0 })
      .withMessage('Price must be greater than 0'),
    body('category')
      .isIn(['concert', 'sports', 'movie'])
      .withMessage('Invalid category'),
    body('venue').trim().notEmpty().withMessage('Venue is required'),
    body('date').isISO8601().withMessage('Invalid date'),
    body('totalSeats')
      .isInt({ gt: 0 })
      .withMessage('Total seats must be greater than 0')
  ],
  validateRequest,
  async (req, res) => {
    try {
      const {
        title,
        description,
        price,
        category,
        venue,
        date,
        totalSeats
      } = req.body;

      const ticket = await Ticket.create({
        title,
        description,
        price,
        category,
        venue,
        date,
        totalSeats,
        availableSeats: totalSeats,
        userId: req.currentUser.id
      });

      res.status(201).json(ticket);
    } catch (err) {
      console.error('Error creating ticket:', err);
      res.status(400).json({
        errors: [{ message: 'Error creating ticket' }]
      });
    }
  }
);

// 更新票务
router.put('/:id',
  requireAuth,
  [
    body('title').trim().optional().notEmpty().withMessage('Title cannot be empty'),
    body('description').trim().optional().notEmpty().withMessage('Description cannot be empty'),
    body('price')
      .optional()
      .isFloat({ gt: 0 })
      .withMessage('Price must be greater than 0'),
    body('category')
      .optional()
      .isIn(['concert', 'sports', 'movie'])
      .withMessage('Invalid category'),
    body('status')
      .optional()
      .isIn(['draft', 'published', 'soldout'])
      .withMessage('Invalid status')
  ],
  validateRequest,
  async (req, res) => {
    const ticket = await Ticket.findOne({
      where: {
        id: req.params.id,
        userId: req.currentUser.id
      }
    });

    if (!ticket) {
      return res.status(404).json({
        errors: [{ message: 'Ticket not found' }]
      });
    }

    await ticket.update(req.body);
    res.json(ticket);
  }
);

// 获取所有票务
router.get('/', async (req, res) => {
  const tickets = await Ticket.findAll({
    where: {
      status: 'published'
    }
  });
  res.json(tickets);
});

// 获取单个票务
router.get('/:id', async (req, res) => {
  const ticket = await Ticket.findOne({
    where: {
      id: req.params.id,
      status: 'published'
    }
  });

  if (!ticket) {
    return res.status(404).json({
      errors: [{ message: 'Ticket not found' }]
      });
  }

  res.json(ticket);
});

module.exports = router; 