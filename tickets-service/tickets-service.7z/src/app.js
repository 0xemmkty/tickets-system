const express = require('express');
const cors = require('cors');
const { errorHandler } = require('./middlewares/error-handler');
const ticketsRouter = require('./routes/tickets');

const app = express();

app.use(cors({
  origin: 'http://localhost:3001',
  credentials: true
}));

app.use(express.json());

// 健康检查路由
app.get('/api/health', (req, res) => {
  res.json({ status: 'healthy' });
});

// 票务路由 - 注意这里的路径
app.use('/api/tickets', ticketsRouter);

// 错误处理中间件
app.use(errorHandler);

module.exports = app; 